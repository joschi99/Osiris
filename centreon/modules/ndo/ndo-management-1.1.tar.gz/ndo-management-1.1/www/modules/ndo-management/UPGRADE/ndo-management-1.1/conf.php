<?php
$upgrade_conf['ndo-management']["rname"] = "ndo-management";
$upgrade_conf['ndo-management']["release_from"] = "1.0";
$upgrade_conf['ndo-management']["release_to"] = "1.1";
$upgrade_conf['ndo-management']["is_removeable"] = "1";
$upgrade_conf['ndo-management']["author"] = "Merethis";
$upgrade_conf['ndo-management']["lang_files"] = "0";
$upgrade_conf['ndo-management']["sql_files"] = "0";
$upgrade_conf['ndo-management']["php_files"] = "0";
?>