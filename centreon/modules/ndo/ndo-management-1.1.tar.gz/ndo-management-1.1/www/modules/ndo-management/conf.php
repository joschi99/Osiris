<?php
// Be Carefull with name, it's case sensitive (with directory module name)
$module_conf['ndo-management']["rname"] = "ndo-management";
$module_conf['ndo-management']["name"] = "ndo-management";
$module_conf['ndo-management']["mod_release"] = "1.1";
$module_conf['ndo-management']["infos"] = "NDOutils Database Management Module ";
$module_conf['ndo-management']["is_removeable"] = "1";
$module_conf['ndo-management']["author"] = "Merethis Team";
$module_conf['ndo-management']["lang_files"] = "0";
$module_conf['ndo-management']["sql_files"] = "1";
$module_conf['ndo-management']["php_files"] = "0";
?>