DELETE FROM topology WHERE topology_page = '609' AND `topology_group` = '35';
DELETE FROM topology WHERE topology_page = '60904';
