<?php

	function purgeNDO($instance_id, $options) {
		global $pearDBndo;
		
		$msg = "";
		$DBRESULT =& $pearDBndo->query("SHOW TABLES");
		while ($data =& $DBRESULT->fetchRow()) {
			foreach ($data as $key => $value) {
				$DBRESULT2 =& $pearDBndo->query("DESCRIBE $value");
				$flag = 0;
				while ($info =& $DBRESULT2->fetchRow()) {
					if ($info["Field"] == "instance_id")
						$flag = 1;
				}
				if ($flag) {
					$pearDBndo->query("DELETE FROM `$value` WHERE instance_id = '$instance_id'");
					$msg .= "&nbsp;&nbsp;-&nbsp;$value : OK<br />";	
				}
			}
		}
		return $msg;
	}

?>