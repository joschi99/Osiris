<?php

	
	if (!isset($oreon))
		exit();
	
	$path = "./modules/ndo-management/purge/";
	
	/*
	 * Pear library
	 */
	require_once "HTML/QuickForm.php";
	require_once "HTML/QuickForm/advmultiselect.php";
	require_once "HTML/QuickForm/Renderer/ArraySmarty.php";

	global $pearDB;
	
	if (file_exists($centreon_path."www/class/centreonDB.class.php"))
		$pearDBndo 	= new CentreonDB("ndo");
	else {
		include_once($centreon_path."www/DBNDOConnect.php");	
	}
	
	/*
	 * Get Poller List
	 */
	$tab_nagios_server = array(NULL => NULL);
	$DBRESULT =& $pearDBndo->query("SELECT * FROM `nagios_instances` ORDER BY `instance_name` DESC");
	if (PEAR::isError($DBRESULT))
		print "DB Error : ".$DBRESULT->getDebugInfo()."<br />";
	while ($nagios =& $DBRESULT->fetchRow())
		$tab_nagios_server[$nagios['instance_id']] = $nagios['instance_name'];
	$DBRESULT->free();
	
	/*
	 * Purge Options
	 */
	
	$options = array();
	$options[] = _("Purge All data");
	$options[] = _("Purge All data without comments / downtimes");
	$options[] = _("Purge All data");
		
	/*
	 * Form begin
	 */
	$attrSelect 	= array("style" => "width: 250px;");
	$attrSelect2 	= array("style" => "width: 150px;");
	$attrsTextarea 	= array("rows"=>"20", "cols"=>"200");

	$form = new HTML_QuickForm('Form', 'post', "?p=".$p);

	$form->addElement('header', 'title', _("Purge Ndo Datases"));
	$form->addElement('select', 'instance', _("Instance"), $tab_nagios_server, $attrSelect);
	//$form->addElement('select', 'options', _("Options"),  $options, $attrSelect2);

	$redirect =& $form->addElement('hidden', 'o');
	$redirect->setValue($o);

	$form->applyFilter('__ALL__', 'myTrim');

	/*
	 * Smarty template Init
	 */
	$tpl = new Smarty();
	$tpl = initSmartyTpl($path, $tpl);

	$sub =& $form->addElement('submit', 'submit', _("Go"));
	$msg = NULL;
	if ($form->validate()) {
		require_once ($path . "DB-Func.php");
		$ret = $form->getSubmitValues();
		/*
		 * Purge Process
		 */
		$msg = purgeNDO($ret["instance"], $ret["options"]);
		
		/*
		 * Display Results
		 */
		$form->addElement('header', 'status', _("Status"));
		if ($msg)
			$tpl->assign('msg', $msg);
	}

	/*
	 * Apply a template definition
	 */
	$renderer =& new HTML_QuickForm_Renderer_ArraySmarty($tpl);
	$form->accept($renderer);
	$tpl->assign('form', $renderer->toArray());
	$tpl->assign('o', $o);
	$tpl->display("purge.ihtml");
?>