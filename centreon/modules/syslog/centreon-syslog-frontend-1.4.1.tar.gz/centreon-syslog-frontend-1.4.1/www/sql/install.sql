CREATE TABLE IF NOT EXISTS `mod_syslog_opt` (
  `sopt_id` int(11) NOT NULL auto_increment,
  `syslog_db_server` varchar(255) default NULL,
  `syslog_db_name` varchar(255) default 'syslog',
  `syslog_db_logs` varchar(255) default 'logs',
  `syslog_db_logs_merge` varchar(255) default 'all_logs',
  `syslog_db_cache` varchar(255) default 'cache',
  `syslog_db_cache_merge` varchar(255) default 'all_cache',
  `syslog_ssh_server` varchar(255) default NULL,
  `syslog_db_user` varchar(255) default 'syslogadmin',
  `syslog_db_password` varchar(255) default NULL,
  `syslog_db_rotate` int(11) default '31',
  `syslog_conf_dir` varchar(255) default '/usr/local/syslog/etc/',
  `syslog_ssh_port` int(11) default '22',
  `syslog_ssh_user` varchar(255) default 'syslog',
  `syslog_ssh_pass` varchar(255) default NULL,
  `syslog_refresh_monitoring` int(15) NOT NULL default '10',
  `syslog_refresh_filters` int(15) NOT NULL default '240',
  PRIMARY KEY  (`sopt_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ;

INSERT INTO `mod_syslog_opt` VALUES (NULL, 'localhost', 'syslog', 'logs', 'all_logs', 'cache', 'all_cache', 'localhost', 'syslogadmin', NULL, 31, '/etc/centreon-syslog', '22', 'syslog', 'syslog', 10, 240 );


-- Administration topology
INSERT INTO `topology` (`topology_id`, `topology_name`, `topology_icone`, `topology_parent`, `topology_page`, `topology_order`, `topology_group`, `topology_url`, `topology_url_opt`, `topology_popup`, `topology_modules`, `topology_show`, `topology_style_class`, `topology_style_id`, `topology_OnClick`) 
VALUES ('', 'Modules', NULL, 507, NULL, NULL, 1, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL) ,
('', 'Syslog', NULL, 507, NULL, NULL, 2, NULL, NULL, NULL, NULL, '1', NULL, NULL, NULL) ,
('', 'Configuration', './img/icones/16x16/text_view.gif', 507, 50710, 10, 2, './modules/Syslog/include/administration/formSyslogAdmin.php', '&o=f', '0', '0', '1', NULL, NULL, NULL) ,
('', 'Syslog', NULL, 2, 204, 40, 1, './modules/Syslog/include/monitoring/syslog.php', NULL, '0', '1', '1', NULL, NULL, NULL) ,
('', 'Monitoring', './img/icones/16x16/text_view.gif', 204, 20401, 40, 1, './modules/Syslog/include/monitoring/syslog.php', NULL, '0', '1', '1', NULL, NULL, NULL) ,
('', 'Search', './img/icones/16x16/text_view.gif', 204, 20402, 40, 1, './modules/Syslog/include/search/syslog_search.php', NULL, '0', '1', '1', NULL, NULL, NULL) ;

-- Administration Javascript topology
INSERT INTO `topology_JS` (`id_t_js`, `id_page`, `o`, `PathName_js`, `Init`) 
VALUES (NULL, '50710', NULL, './modules/Syslog/include/administration/javascript/changetab.js', NULL ) ,
(NULL, '50710', NULL, './modules/Syslog/include/administration/javascript/exportConf.js', NULL ) ,
(NULL, '20402', NULL, './modules/Syslog/include/search/javascript/exportCSV.js', NULL ) ,
(NULL, '20402', NULL, './include/common/javascript/datePicker.js', NULL ) ,
(NULL, '20402', NULL, './include/common/javascript/tool.js', NULL ) ;

CREATE TABLE IF NOT EXISTS `mod_syslog_filters_facility` (
  `key` varchar(255) default NULL,
  `value` varchar(255) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `mod_syslog_filters_facility`
VALUE ('kern', 0), 
('user', '1'), 
('mail', '2'), 
('daemon', '3'), 
('auth', '4'), 
('security', '4'),
('syslog', '5'), 
('lpr', '6'), 
('news', '7'), 
('uucp', '8'), 
('cron', '9'), 
('authpriv', '10'), 
('ftp', '11'), 
('local0', '16'), 
('local1', '17'), 
('local2', '18'), 
('local3', '19'), 
('local4', '20'), 
('local5', '21'), 
('local6', '22'), 
('local7', '23');

CREATE TABLE IF NOT EXISTS `mod_syslog_filters_priority` (
  `key` varchar(255) default NULL,
  `value` varchar(255) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `mod_syslog_filters_priority`
VALUE ('emerg', 0), 
('panic', 0), 
('alert', '1'), 
('crit', '2'), 
('error', '3'), 
('err', '3'), 
('warning', '4'),
('warn', '4'),
('notice', '5'), 
('info', '6'), 
('debug', '7');