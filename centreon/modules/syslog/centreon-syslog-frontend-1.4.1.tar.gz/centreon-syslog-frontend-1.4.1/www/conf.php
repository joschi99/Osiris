<?php
$module_conf['Syslog']["name"] = "Syslog";
$module_conf['Syslog']["rname"] = "Syslog  Module";
$module_conf['Syslog']["mod_release"] = "1.4.1";
$module_conf['Syslog']["version"] = "1.4.1";
$module_conf['Syslog']["is_removeable"] = "1";
$module_conf['Syslog']["author"] = "Syslog team for Centreon 2.1 compatibility";
$module_conf['Syslog']["infos"] = "Syslog viewer for Centreon Syslog server.";
$module_conf['Syslog']["lang_files"] = "1";
$module_conf['Syslog']["sql_files"] = "1";
$module_conf['Syslog']["php_files"] = "0";
?>