-- Administration Javascript topology
INSERT INTO `topology_JS` (`id_t_js`, `id_page`, `o`, `PathName_js`, `Init`) 
VALUES (NULL, '20402', NULL, './modules/Syslog/include/search/javascript/exportCSV.js', NULL ) ;