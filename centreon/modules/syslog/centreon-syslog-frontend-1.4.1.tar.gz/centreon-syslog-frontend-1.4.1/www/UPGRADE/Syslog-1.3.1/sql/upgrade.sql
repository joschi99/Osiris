-- Database information
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_server` `syslog_db_server` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ;
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_db` `syslog_db_name` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'syslog' ;
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_server_db_user` `syslog_db_user` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'syslogadmin' ; 
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_server_db_password` `syslog_db_password` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ;
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_db_table` `syslog_db_logs` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'logs' ;
ALTER TABLE `mod_syslog_opt` ADD `syslog_db_logs_merge` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'all_logs' AFTER `syslog_db_logs` ;
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_db_filter` `syslog_db_cache` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'cache' ;
ALTER TABLE `mod_syslog_opt` ADD `syslog_db_cache_merge` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'all_cache' AFTER `syslog_db_cache` ;
ALTER TABLE `mod_syslog_opt` ADD `syslog_refresh_monitoring` INT( 15 ) NOT NULL DEFAULT '10' AFTER `syslog_shell_pass` ;
ALTER TABLE `mod_syslog_opt` ADD `syslog_refresh_filters` INT( 15 ) NOT NULL DEFAULT '240' AFTER `syslog_refresh_monitoring` ;

-- SSH information
ALTER TABLE `mod_syslog_opt` ADD `syslog_ssh_server` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL AFTER `syslog_db_cache_merge`;
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_shell_user` `syslog_ssh_user` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'syslog' ;
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_shell_pass` `syslog_ssh_pass` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'syslog' ;
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_ssh_port` `syslog_ssh_port` INT( 11 ) NULL DEFAULT '22' ;

-- Configuration
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_conf_dir` `syslog_conf_dir` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '/usr/local/syslog/etc/' ;
ALTER TABLE `mod_syslog_opt` CHANGE `syslog_db_rotate` `syslog_db_rotate` INT( 11 ) NULL DEFAULT '31' ;

UPDATE `topology` SET `topology_url` = './modules/Syslog/include/administration/formSyslogAdmin.php' WHERE `topology`.`topology_url` ='./modules/Syslog/syslog_options.php' LIMIT 1 ;
UPDATE `topology` SET `topology_url_opt` = '&o=f' WHERE `topology`.`topology_url` ='./modules/Syslog/include/administration/formSyslogAdmin.php' LIMIT 1 ;
UPDATE `topology` SET `topology_url` = './modules/Syslog/include/monitoring/syslog.php' WHERE `topology`.`topology_url`='./modules/Syslog/view/syslog.php' LIMIT 1 ;

INSERT INTO `topology_JS` (`id_t_js`, `id_page`, `o`, `PathName_js`, `Init`) 
VALUES (NULL, '50710', NULL, './modules/Syslog/include/administration/javascript/changetab.js', NULL ) ,
(NULL, '50710', NULL, './modules/Syslog/include/administration/javascript/exportConf.js', NULL ) ;

UPDATE `topology` SET `topology_url` = 'modules/Syslog/include/monitoring/syslog.php' WHERE `topology`.`topology_page` =204 LIMIT 1 ;
UPDATE `topology` SET `topology_url` = 'modules/Syslog/include/monitoring/syslog.php' WHERE `topology`.`topology_page` =20401 LIMIT 1 ;
UPDATE `topology` SET `topology_url` = 'modules/Syslog/include/search/syslog_search.php' WHERE `topology`.`topology_page` =20402 LIMIT 1 ;

CREATE TABLE IF NOT EXISTS `mod_syslog_filters_facility` (
  `key` varchar(255) default NULL,
  `value` varchar(255) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `mod_syslog_filters_facility`
VALUE ('kern', 0), 
('user', '1'), 
('mail', '2'), 
('daemon', '3'), 
('auth', '4'), 
('security', '4'),
('syslog', '5'), 
('lpr', '6'), 
('news', '7'), 
('uucp', '8'), 
('cron', '9'), 
('authpriv', '10'), 
('ftp', '11'), 
('local0', '16'), 
('local1', '17'), 
('local2', '18'), 
('local3', '19'), 
('local4', '20'), 
('local5', '21'), 
('local6', '22'), 
('local7', '23');

CREATE TABLE IF NOT EXISTS `mod_syslog_filters_priority` (
  `key` varchar(255) default NULL,
  `value` varchar(255) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `mod_syslog_filters_priority`
VALUE ('emerg', 0), 
('panic', 0), 
('alert', '1'), 
('crit', '2'), 
('error', '3'), 
('err', '3'), 
('warning', '4'),
('warn', '4'),
('notice', '5'), 
('info', '6'), 
('debug', '7');

-- Administration Javascript topology
INSERT INTO `topology_JS` (`id_t_js`, `id_page`, `o`, `PathName_js`, `Init`) 
VALUES (NULL, '20402', NULL, './modules/Syslog/include/search/javascript/exportCSV.js', NULL ) ;