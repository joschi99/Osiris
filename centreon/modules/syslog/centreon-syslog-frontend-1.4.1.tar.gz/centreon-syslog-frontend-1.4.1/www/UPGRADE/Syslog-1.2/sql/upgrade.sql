ALTER TABLE `mod_syslog_opt` ADD `syslog_db_rotate` INT( 11 ) NULL DEFAULT '30' AFTER `syslog_server_db_password` ;
ALTER TABLE `mod_syslog_opt` ADD  `syslog_conf_dir` VARCHAR( 50 ) NULL DEFAULT  '/etc/syslog' AFTER  `syslog_db_rotate` ;
ALTER TABLE `mod_syslog_opt` ADD  `syslog_shell_user` VARCHAR( 255 ) NULL DEFAULT  'syslog' AFTER  `syslog_conf_dir` ;
ALTER TABLE  `mod_syslog_opt` ADD  `syslog_shell_pass` VARCHAR( 255 ) NULL AFTER  `syslog_shell_user` ;
ALTER TABLE  `mod_syslog_opt` ADD  `syslog_ssh_port` INT NOT NULL DEFAULT  '22' AFTER  `syslog_conf_dir` ;

UPDATE `mod_syslog_opt` SET `syslog_db_filter` = "all_cache" ;

INSERT INTO `topology` (`topology_id`, `topology_name`, `topology_icone`, `topology_parent`, `topology_page`, `topology_order`, `topology_group`, `topology_url`, `topology_url_opt`, `topology_popup`, `topology_modules`, `topology_show`, `topology_style_class`, `topology_style_id`, `topology_OnClick`) VALUES ('', 'Research', './img/icones/16x16/text_view.gif', 204, 20402, 40, 1, './modules/Syslog/search/syslog_search.php', NULL, '0', '1', '1', NULL, NULL, NULL);
UPDATE `topology` SET `topology_name` = 'Search' WHERE `topology`.`topology_page` =20402 LIMIT 1 ;
UPDATE `topology` SET `topology_url` = "./modules/Syslog/view/syslog.php" WHERE `topology_url` = "./modules/Syslog/syslog.php" ;

INSERT INTO `topology_JS` (`id_t_js`, `id_page`, `o`, `PathName_js`, `Init`) VALUES (NULL, '20402', NULL, './include/common/javascript/datePicker.js', NULL );
INSERT INTO `topology_JS` (`id_t_js`, `id_page`, `o`, `PathName_js`, `Init`) VALUES (NULL, '20402', NULL, './include/common/javascript/tool.js', NULL );

