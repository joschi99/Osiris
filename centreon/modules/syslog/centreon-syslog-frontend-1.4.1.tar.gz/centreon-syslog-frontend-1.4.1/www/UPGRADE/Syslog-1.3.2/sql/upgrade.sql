UPDATE topology SET topology_url = './modules/Syslog/include/administration/formSyslogAdmin.php' WHERE topology.topology_url ='./modules/Syslog/syslog_options.php' LIMIT 1 ;
UPDATE topology SET topology_url_opt = '&o=f' WHERE topology.topology_url ='./modules/Syslog/include/administration/formSyslogAdmin.php' LIMIT 1 ;
UPDATE topology SET topology_url = './modules/Syslog/include/monitoring/syslog.php' WHERE topology.topology_url='./modules/Syslog/view/syslog.php' LIMIT 1 ;
UPDATE topology SET topology_url = 'modules/Syslog/include/monitoring/syslog.php' WHERE topology.topology_page =204 LIMIT 1 ;
UPDATE topology SET topology_url = 'modules/Syslog/include/monitoring/syslog.php' WHERE topology.topology_page =20401 LIMIT 1 ;
UPDATE topology SET topology_url = 'modules/Syslog/include/search/syslog_search.php' WHERE topology.topology_page =20402 LIMIT 1 ;