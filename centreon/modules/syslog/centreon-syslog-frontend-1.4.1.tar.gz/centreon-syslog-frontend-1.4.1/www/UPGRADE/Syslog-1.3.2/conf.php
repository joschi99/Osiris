<?php
$upgrade_conf['Syslog']["name"] = "Syslog";
$upgrade_conf['Syslog']["rname"] = "Syslog  Module";
$upgrade_conf['Syslog']["release_from"] = "1.3.1";
$upgrade_conf['Syslog']["release_to"] = "1.3.2";
$upgrade_conf['Syslog']["is_removeable"] = "1";
$upgrade_conf['Syslog']["author"] = "Syslog team for Centreon 2.1 compatibility";
$upgrade_conf['Syslog']["infos"] = "Syslog viewer for Centreon Syslog server.";
$upgrade_conf['Syslog']["lang_files"] = "1";
$upgrade_conf['Syslog']["sql_files"] = "1";
$upgrade_conf['Syslog']["php_files"] = "0";
?>