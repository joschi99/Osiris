<?php

/*
 * Author :      Pierre Villard
 * License :     Creative Commons - Attribution-ShareAlike 3.0 Unported
 *               (http://creativecommons.org/licenses/by-sa/3.0/)
 *
 * >> Module designed to integrate Nagvis tool in Centreon <<
 *
 * Tested with Centreon 2.4.1 and Nagvis 1.7.8
 *
 * This module modifies Nagvis source code and installs a Centreon
 * module in order to integrate Nagvis in Centreon. It assumes you
 * created a Nagvis user that will be used to automatically log in
 * Centreon users in Nagvis. However it will always be possible to
 * log out from Nagvis interface to use a different user : it will
 * remain integrated in Centreon interface.
 *
 */

if (!isset ($oreon)) {
		exit ();
}

function displayCentreonNagvis($data){
 $form = '
 <script type="text/javascript" src="./modules/nagvis/javascript/jquery.js"></script>
 <script type="text/javascript" src="./modules/nagvis/javascript/jquery.autoheight.js"></script>
 <iframe id="frmnagvis" name="frmnagvis" class="autoHeight" frameborder="0" scrolling="yes" src="'.$data.'" style="width:100%"></iframe> 	
 ';
 return $form;
}

function curPageURL() {
 $pageURL = 'http';
 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
 $pageURL .= "://";
 if ($_SERVER["SERVER_PORT"] != "80") {
  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
 } else {
  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
 }
 return $pageURL;
}

?>
