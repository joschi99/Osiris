<?php

/* 
 * Author :      Pierre Villard
 * License :     Creative Commons - Attribution-ShareAlike 3.0 Unported
 *               (http://creativecommons.org/licenses/by-sa/3.0/)
 *
 * >> Module designed to integrate Nagvis tool in Centreon <<
 *
 * Tested with Centreon 2.4.1 and Nagvis 1.7.8
 * 
 * This module modifies Nagvis source code and installs a Centreon
 * module in order to integrate Nagvis in Centreon. It assumes you
 * created a Nagvis user that will be used to automatically log in
 * Centreon users in Nagvis. However it will always be possible to
 * log out from Nagvis interface to use a different user : it will
 * remain integrated in Centreon interface.
 *
 */
 
    if (!isset ($oreon)) {
	exit ();
    }

    require_once 'utils.php';
	
    $url=curPageURL();

    if(strpos($url,'mod=Map') !== false) {
        $explode=explode("show=",$url);
        $map=$explode[1];
        print displayCentreonNagvis("../nagvis/index.php?mod=Map&act=view&show=".$map);
    } else {
        print displayCentreonNagvis("{URL_NAGVIS_FRONTEND}?readonly");
    }

?>
