#!/bin/sh

#
# Author :      Pierre Villard
# License :     Creative Commons - Attribution-ShareAlike 3.0 Unported
#               (http://creativecommons.org/licenses/by-sa/3.0/)
#
# >> Module designed to integrate Nagvis tool in Centreon <<
#
# Tested with Centreon 2.4.1 and Nagvis 1.7.8
#
# This module modifies Nagvis source code and installs a Centreon
# module in order to integrate Nagvis in Centreon. It assumes you
# created a Nagvis user that will be used to automatically log in
# Centreon users in Nagvis. However it will always be possible to
# log out from Nagvis interface to use a different user : it will
# remain integrated in Centreon interface.
#

# Configuration
PATH_CENTREON_MODULES='/opt/mtcf/centreon/www/modules'
PATH_NAGVIS='/opt/mtcf/nagvis'
PATH_NAGVIS_CORE='/opt/mtcf/nagvis/share/server/core'
USER_NAGVIS_READONLY='nagvis'

# Uninstall...
echo "Uninstalling..."

TEMPDIR=`mktemp -d`

cp -rf nagvis.patch $TEMPDIR
sed -i 's|{USER_READONLY}|'$USER_NAGVIS_READONLY'|g' $TEMPDIR/nagvis.patch
sed -i 's|{NAGVIS_CORE_PATH}|'$PATH_NAGVIS_CORE'|g' $TEMPDIR/nagvis.patch

pushd /opt
patch -p0 -R < $TEMPDIR/nagvis.patch
popd

rm -rf $PATH_CENTREON_MODULES"/nagvis"
rm -rf $TEMPDIR

echo "Done !"
